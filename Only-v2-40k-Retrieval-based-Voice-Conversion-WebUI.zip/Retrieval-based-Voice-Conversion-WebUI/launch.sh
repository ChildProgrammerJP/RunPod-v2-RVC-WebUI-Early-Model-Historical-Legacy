#!/bin/sh

# 仮想環境をアクティブ化
. venv/bin/activate

# RVC WebUIを起動
python3.10 infer-web.py
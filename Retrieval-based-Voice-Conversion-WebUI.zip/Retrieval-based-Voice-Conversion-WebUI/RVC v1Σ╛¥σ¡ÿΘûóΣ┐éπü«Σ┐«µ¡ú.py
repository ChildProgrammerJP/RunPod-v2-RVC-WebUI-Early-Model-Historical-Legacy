対策
ffmpeg==1.4はpipインストールしない
他の依存関係を合わせる


# ダメな方にないもの

coloredlogs==15.0.1
flatbuffers==24.3.25
humanfriendly==10.0
hydra-core==1.0.7
onnxruntime-gpu==1.19.2
rfc3986==1.5.0

torchcrepe==0.0.20
 
 
 !pip3 install --use-pep517 --root-user-action=ignore coloredlogs==15.0.1 flatbuffers==24.3.25 humanfriendly==10.0 hydra-core==1.0.7 onnxruntime-gpu==1.19.2 rfc3986==1.5.0
 
# ダメな方にあるもの

ffmpeg==1.4
functorch==2.0.0
hydra-core==1.0.7


!pip3 uninstall -y --use-pep517 --root-user-action=ignore ffmpeg==1.4functorch==2.0.0 hydra-core==1.0.7

→hydra-core==1.0.7 はfumiama v1版では起動時に必要
!pip3 install --use-pep517 --root-user-action=ignore hydra-core==1.0.7

 
# バージョン違い 良い方
librosa==0.9.1（ダメな方は 0.9.2）
h11==0.12.0（ダメな方は 0.14.0）
httpcore==0.15.0（ダメな方は 1.0.6）変わり過ぎか
httpx==0.23.0（ダメな方は 0.27.2）
jedi==0.18.2（ダメな方は 0.19.1）
onnx==1.17.0（ダメな方は 0.15.0）

 !pip3 install --use-pep517 --root-user-action=ignore librosa==0.9.1 h11==0.12.0 httpcore==0.15.0 httpx==0.23.0 jedi==0.18.2 onnx==1.17.0
 
 
 ＊＊＊
 一時保存
 

gradio==3.26.0
tqdm==4.65.0
numpy==1.23.5
faiss-cpu==1.7.3
fairseq==0.12.2
matplotlib==3.7.1
scipy==1.9.3
librosa==0.9.2
praat-parselmouth==0.4.3
pyworld==0.3.2
soundfile==0.12.1
ffmpeg-python==0.2.0
pydub==0.25.1
soxr==0.3.5
transformers==4.28.1

tensorboard
tensorboardX
requests

nvidia-cudnn-cu12==8.9.6.50
 
 